#include "defs.h"

int main()
{      
	Iniciar();
    return 0;
}
